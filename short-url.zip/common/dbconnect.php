<?php
	include("DB.class.php");
	$short=new DB("short");
?>